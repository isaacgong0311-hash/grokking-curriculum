# Grouping by Result, Not Difficulty, Delays Grokking

Code and results for the paper investigating whether the order in which
training examples are presented affects the grokking transition in
transformers trained on modular arithmetic. See the paper for full context;
this repo covers Study 2 (training from scratch) and its task-breadth and
model-scale extensions.

**Preprint:** https://doi.org/10.5281/zenodo.21520844

## What's actually in this repo (read before citing it as "reproducible")

- `src/model.py` -- the `GrokkTransformer` architecture, extracted verbatim
  from the training notebook.
- `src/data.py` -- dataset construction, the 50/50 train/val split, and the
  five curriculum orderings. The `add` and `mul` paths are verbatim; the
  `sub` (subtraction) path is **reconstructed** from the paper's stated
  definition, not verified against the author's own subtraction run code
  (which wasn't located when this repo was assembled) -- see the docstring
  in that file.
- `src/train.py` -- the single-run training loop (verbatim, with the Colab
  Google-Drive mount replaced by a plain output directory).
- `src/stats_analysis.py` -- Welch's t-test, the exact permutation test,
  Mann-Whitney U, and the Gini-coefficient mechanism check (verbatim).
- `results/summary.json` -- the aggregate grokking-step numbers reported in
  the paper's tables.

**What's NOT in here yet:** raw per-step training logs and embedding
checkpoints (`history.json` / `embed_log.npz` per run) currently live in
the author's own Google Drive, not this repo. The per-residue-class
accuracy data behind Figure 6 also isn't included. Study 1 (the GPT-2
fine-tuning exploratory experiment) has no code in this repo -- it lives
in a separate, not-yet-located notebook. If you're the author: add those
before pointing a reviewer at this repo as the reproducibility source, or
adjust the paper's Reproducibility section to describe accurately what's
actually here.

## Reproducing a single run

```bash
pip install -r requirements.txt
cd src
python train.py   # trains one seed of residue-blocks addition mod 97
```

This writes `history.json` (per-eval-step metrics) and `embed_log.npz`
(embedding matrix snapshots) to `./runs/add_p97_residue_blocks_s0/`.

To run a different condition/seed/operation, edit the `Config(...)` call at
the bottom of `train.py` or import `train` and call it from your own
script:

```python
from data import Config
from train import train

cfg = Config(modulus=97, operation='add', curriculum='balanced_mini_epoch', seed=2,
             out_dir='./runs/my_run')
train(cfg)
```

For the "tiny" / "large" model-scale points (Table 6), pass the
architecture from `model.MODEL_SCALE_CONFIGS`:

```python
from model import MODEL_SCALE_CONFIGS
cfg = Config(modulus=97, operation='add', curriculum='random', seed=0,
             out_dir='./runs/tiny_random_s0', **MODEL_SCALE_CONFIGS['tiny'])
```

## Reproducing the statistics

```python
import json
from stats_analysis import compare_conditions

summary = json.load(open('../results/summary.json'))
run = summary['residue_blocks_vs_random_5seed']
compare_conditions(run['grokking_step']['random'], run['grokking_step']['residue_blocks'],
                    'random', 'residue_blocks')
```

## Citing

If you use this code, please cite the paper (see the Zenodo DOI above for
citation details).
