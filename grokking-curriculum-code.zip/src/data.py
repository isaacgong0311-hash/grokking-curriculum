"""
Dataset construction, train/val split, and the five curriculum orderings.

make_pairs(), split_data(), apply_curriculum(), and _wrap_difficulty() for
'add' are extracted verbatim from the author's Colab notebook
(strengthen_residue_result.ipynb, cell 3). That notebook only ran addition,
so the 'sub' branches below (marked RECONSTRUCTED) were added to match the
subtraction wrapping definition described in the paper (Sec 3.1: a pair is
wrapping/hard if (a - b) < 0) -- they have NOT been verified against the
author's actual subtraction/multiplication run code, which was not located.
Verify these against your own run logs before treating Table 5 (task
breadth) as fully reproduced from this repo.
"""
import random
from dataclasses import dataclass


@dataclass
class Config:
    modulus: int = 97
    operation: str = 'add'          # 'add', 'sub', or 'mul'
    train_fraction: float = 0.5
    d_model: int = 128
    n_heads: int = 4
    n_layers: int = 2
    lr: float = 1e-3
    weight_decay: float = 1.0
    batch_size: int = 512
    max_steps: int = 30000
    warmup_steps: int = 100
    eval_every: int = 250
    embed_every: int = 500
    curriculum: str = 'random'
    seed: int = 0
    out_dir: str = ''


def _apply_op(a, b, p, operation):
    if operation == 'add':
        return (a + b) % p
    if operation == 'mul':
        return (a * b) % p
    if operation == 'sub':  # RECONSTRUCTED -- see module docstring
        return (a - b) % p
    raise ValueError('unknown operation: ' + str(operation))


def make_pairs(cfg):
    p = cfg.modulus
    out = []
    for a in range(p):
        for b in range(p):
            c = _apply_op(a, b, p, cfg.operation)
            out.append((a, b, c))
    return out


def split_data(pairs, frac, seed):
    """50/50 (by default) train/val split, reseeded per run from the same
    `seed` as the model's own initialization -- NOT a fixed split shared
    across seeds, and not stratified by residue class."""
    rng = random.Random(seed)
    shuf = list(pairs)
    rng.shuffle(shuf)
    n = int(len(shuf) * frac)
    return shuf[:n], shuf[n:]


def _wrap_difficulty(triple, cfg):
    """Wrapping/hard-pair proxy. 'add' and 'mul' use the modulus-crossing
    threshold ((a+b) >= p or (a*b) >= p) exactly as run. 'sub' uses (a - b)
    < 0, per the paper's Sec 3.1 definition -- RECONSTRUCTED, not verified
    against the author's own subtraction code."""
    a, b, _ = triple
    if cfg.operation == 'add':
        raw = a + b
        return 1 if raw >= cfg.modulus else 0
    if cfg.operation == 'mul':
        raw = a * b
        return 1 if raw >= cfg.modulus else 0
    if cfg.operation == 'sub':  # RECONSTRUCTED -- see module docstring
        return 1 if (a - b) < 0 else 0
    raise ValueError('unknown operation: ' + str(cfg.operation))


def apply_curriculum(pairs, curriculum, cfg):
    if curriculum == 'random':
        return list(pairs)
    if curriculum in ('easy_hard', 'hard_easy'):
        s = sorted(pairs, key=lambda t: _wrap_difficulty(t, cfg))
        return s[::-1] if curriculum == 'hard_easy' else s
    if curriculum == 'residue_blocks':
        blocks = {}
        for t in pairs:
            blocks.setdefault(t[2], []).append(t)
        out = []
        for c in sorted(blocks):
            out.extend(blocks[c])
        return out
    if curriculum == 'balanced_mini_epoch':
        blocks = {}
        for t in pairs:
            blocks.setdefault(t[2], []).append(t)
        rng = random.Random(cfg.seed)
        for c in blocks:
            rng.shuffle(blocks[c])
        out = []
        iters = {c: iter(v) for c, v in sorted(blocks.items())}
        active = sorted(blocks.keys())
        while active:
            nxt = []
            for c in active:
                try:
                    out.append(next(iters[c]))
                    nxt.append(c)
                except StopIteration:
                    pass
            active = nxt
        return out
    raise ValueError('unknown curriculum: ' + str(curriculum))


CURRICULA = ['random', 'easy_hard', 'hard_easy', 'residue_blocks', 'balanced_mini_epoch']


if __name__ == '__main__':
    # Sanity check from the original notebook: every curriculum must be a
    # permutation of the training set, never adding or dropping examples.
    _cfg = Config(modulus=13)
    _tr, _va = split_data(make_pairs(_cfg), 0.5, 0)
    for _c in CURRICULA:
        _o = apply_curriculum(_tr, _c, _cfg)
        assert sorted(_o) == sorted(_tr), _c + ' is not a permutation'
    print('all orderings valid')
