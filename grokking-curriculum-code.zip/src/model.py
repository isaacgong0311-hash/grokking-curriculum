"""
GrokkTransformer: the model used for Study 2 (training from scratch) and its
extensions (task breadth, model scale).

Extracted verbatim from the author's Colab notebook
(strengthen_residue_result.ipynb, cell 2 "Model (unchanged from the original
grid's code)") -- not rewritten or reconstructed.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class Attention(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        self.n_heads = n_heads
        self.d_head = d_model // n_heads
        self.qkv = nn.Linear(d_model, 3 * d_model, bias=False)
        self.out = nn.Linear(d_model, d_model, bias=False)

    def forward(self, x):
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.n_heads, self.d_head)
        q, k, v = qkv[:, :, 0], qkv[:, :, 1], qkv[:, :, 2]
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)
        att = (q @ k.transpose(-2, -1)) / math.sqrt(self.d_head)
        mask = torch.triu(torch.ones(T, T, device=x.device), diagonal=1).bool()
        att = att.masked_fill(mask, float('-inf'))
        att = F.softmax(att, dim=-1)
        y = (att @ v).transpose(1, 2).reshape(B, T, C)
        return self.out(y)


class Block(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = Attention(d_model, n_heads)
        self.ln2 = nn.LayerNorm(d_model)
        self.mlp = nn.Sequential(
            nn.Linear(d_model, 4 * d_model, bias=False),
            nn.GELU(),
            nn.Linear(4 * d_model, d_model, bias=False),
        )

    def forward(self, x):
        x = x + self.attn(self.ln1(x))
        x = x + self.mlp(self.ln2(x))
        return x


class GrokkTransformer(nn.Module):
    """
    Decoder-only transformer over a fixed-length sequence [a, OP, b, EQ].
    Reads out only the final position's hidden state and projects to p
    result classes -- the model predicts the answer in a single forward
    pass, not autoregressively.

    Default d_model=128, n_heads=4, n_layers=2 gives the ~420k-parameter
    "small" model used for the main Study 2 results (Sections 4.1-4.6 of
    the paper). The model-scale extension (Section 4.8) varies d_model /
    n_heads / n_layers to get the "tiny" (62k) and "large" (3.2M) sizes --
    see MODEL_SCALE_CONFIGS below.
    """
    def __init__(self, p, d_model=128, n_heads=4, n_layers=2, seq_len=4):
        super().__init__()
        self.p = p
        self.embed = nn.Embedding(p + 2, d_model)  # p result classes + OP + EQ tokens
        self.pos = nn.Parameter(torch.randn(seq_len, d_model) * 0.02)
        self.blocks = nn.ModuleList([Block(d_model, n_heads) for _ in range(n_layers)])
        self.ln_f = nn.LayerNorm(d_model)
        self.unembed = nn.Linear(d_model, p, bias=False)

    def forward(self, x):
        h = self.embed(x) + self.pos[:x.shape[1]]
        for blk in self.blocks:
            h = blk(h)
        return self.unembed(self.ln_f(h))[:, -1, :]

    def number_embeddings(self):
        # .copy() is required -- see repo README for why.
        return self.embed.weight[:self.p].detach().cpu().numpy().copy()


# Model sizes used in the Section 4.8 scale extension. "small" reproduces
# the 420k-parameter architecture above; "tiny" and "large" are the other
# two points in Table 6. Parameter counts are approximate and depend
# slightly on p (via the embedding table); reported paper counts are for
# p=97.
MODEL_SCALE_CONFIGS = {
    "tiny":  dict(d_model=64,  n_heads=2, n_layers=1),   # ~62k params at p=97
    "small": dict(d_model=128, n_heads=4, n_layers=2),   # ~420k params at p=97 (default)
    "large": dict(d_model=256, n_heads=8, n_layers=4),   # ~3.2M params at p=97
}
