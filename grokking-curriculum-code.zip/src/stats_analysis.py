"""
Statistical tests used in the paper: Welch's t-test, an exact (full-
enumeration) permutation test, Mann-Whitney U, and the Gini-coefficient
mechanism check (Sec 4.4 / Table 4).

Extracted verbatim from the author's Colab notebook
(strengthen_residue_result.ipynb, cells 8-9b), with argument names
generalized slightly so these run on any two condition's grokking-step
lists, not just the random-vs-residue-blocks comparison the notebook was
built for.
"""
from itertools import combinations

import numpy as np
from scipy import stats as scipy_stats


def exact_permutation_p(a, b):
    """Exact two-sided permutation test by full enumeration (not Monte
    Carlo): at n=5 vs n=5 this checks all C(10,5)=252 splits; at n=3 vs
    n=3, all C(6,3)=20. A split tied with the observed statistic is
    counted via a small numerical tolerance (1e-9) rather than dropped to
    floating-point error -- the observed split itself is always included,
    the standard conservative convention."""
    combined = np.array(list(a) + list(b))
    n_a = len(a)
    n_total = len(combined)
    observed = abs(np.mean(a) - np.mean(b))
    diffs = []
    for combo in combinations(range(n_total), n_a):
        ga = combined[list(combo)]
        gb = np.delete(combined, list(combo))
        diffs.append(abs(np.mean(ga) - np.mean(gb)))
    diffs = np.array(diffs)
    p = np.mean(diffs >= observed - 1e-9)
    return p, len(diffs)


def compare_conditions(vals_a, vals_b, label_a='condition A', label_b='condition B'):
    """Runs all three tests used in the paper (Sec 3.5 / 4.3) on two lists
    of per-seed grokking steps and prints a summary matching Table 3's
    reporting."""
    t, p_welch = scipy_stats.ttest_ind(vals_a, vals_b, equal_var=False)
    p_perm, n_combos = exact_permutation_p(vals_a, vals_b)
    u, p_mw = scipy_stats.mannwhitneyu(vals_a, vals_b, alternative='two-sided')

    mean_a, sd_a = np.mean(vals_a), np.std(vals_a, ddof=1)
    mean_b, sd_b = np.mean(vals_b), np.std(vals_b, ddof=1)
    pct = (mean_b - mean_a) / mean_a * 100

    print('%-16s n=%d  mean %.0f +/- %.0f' % (label_a, len(vals_a), mean_a, sd_a))
    print('%-16s n=%d  mean %.0f +/- %.0f   (%+.1f%% vs %s)'
          % (label_b, len(vals_b), mean_b, sd_b, pct, label_a))
    print()
    print("Welch's t-test:         t=%.3f  p=%.4f" % (t, p_welch))
    print('Exact permutation test:  p=%.4f  (%d splits enumerated)' % (p_perm, n_combos))
    print('Mann-Whitney U:          U=%.1f  p=%.4f' % (u, p_mw))
    return dict(t=t, p_welch=p_welch, p_perm=p_perm, n_combos=n_combos, u=u, p_mw=p_mw,
                mean_a=mean_a, sd_a=sd_a, mean_b=mean_b, sd_b=sd_b, pct=pct)


def gini(x):
    """Gini coefficient of a nonnegative vector (used on the mean-magnitude
    Fourier spectrum of the embedding matrix, Sec 4.4)."""
    x = np.sort(np.abs(np.asarray(x, dtype=np.float64)))
    n = len(x)
    if x.sum() == 0:
        return 0.0
    idx = np.arange(1, n + 1)
    return float(((2 * idx - n - 1) * x).sum() / (n * x.sum()))


def load_gini_series(embed_log_path):
    """Loads an embed_log.npz (written by train.py) and returns
    (steps, gini_series) for the embedding's Fourier spectrum over
    training."""
    z = np.load(embed_log_path)
    steps, embeds = z['steps'], z['embeds']
    spec = np.abs(np.fft.rfft(embeds, axis=1)).mean(axis=2)
    series = np.array([gini(spec[i]) for i in range(spec.shape[0])])
    return steps, series


def half_rise_step(steps, series, reference_value):
    """First step at which `series` reaches halfway between its initial
    value and `reference_value`. The paper (Sec 4.4) uses the series'
    value near the run's own grokking step as the reference -- NOT the
    value at the end of the full run, which the notebook's first attempt
    (cell 9) used before being corrected in cell 9b. Pass the grokking-
    step-referenced value here to match Table 4."""
    g0 = series[0]
    if reference_value <= g0:
        return None
    target = g0 + 0.5 * (reference_value - g0)
    for s, v in zip(steps, series):
        if v >= target:
            return int(s)
    return None


if __name__ == '__main__':
    # Reproduces the n=3 -> n=5 sample-size-floor argument from the paper
    # (Sec 3.5 / 4.3): with 3 vs 3, no exact test can report below p=0.10.
    for n in (3, 5):
        n_combos = len(list(combinations(range(2 * n), n)))
        print('n=%d vs n=%d: C(%d,%d)=%d splits, floor p = 2/%d = %.4f'
              % (n, n, 2 * n, n, n_combos, n_combos, 2 / n_combos))
