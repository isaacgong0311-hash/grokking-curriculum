"""
Training loop for a single (condition, seed) run.

Extracted verbatim from the author's Colab notebook
(strengthen_residue_result.ipynb, cell 4 "Training loop (unchanged)"),
except that the hardcoded Google Drive mount / DRIVE_DIR from the notebook
has been replaced with a plain `out_dir` argument so this runs outside
Colab. Behavior is otherwise unchanged: each run seeds Python's random
module, NumPy, and PyTorch (CPU + CUDA) from the same `cfg.seed`, uses
cuDNN deterministic mode, and defines "grokking step" as the first logged
evaluation step where validation accuracy reaches 95%.
"""
import json
import math
import os
import random
import time

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

from data import Config, make_pairs, split_data, apply_curriculum
from model import GrokkTransformer

device = 'cuda' if torch.cuda.is_available() else 'cpu'


def set_all_seeds(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def weight_norm(model):
    tot = 0.0
    for p_ in model.parameters():
        tot += float(p_.detach().pow(2).sum().item())
    return math.sqrt(tot)


@torch.no_grad()
def accuracy(model, x, y, bs=2048):
    model.eval()
    correct = 0
    for i in range(0, len(x), bs):
        logits = model(x[i:i + bs].to(device))
        correct += int((logits.argmax(-1) == y[i:i + bs].to(device)).sum().item())
    model.train()
    return correct / len(x)


def to_tensors(pairs, cfg):
    p = cfg.modulus
    OP, EQ = p, p + 1
    x = torch.tensor([[a, OP, b, EQ] for a, b, _ in pairs], dtype=torch.long)
    y = torch.tensor([c for _, _, c in pairs], dtype=torch.long)
    return x, y


def train(cfg: Config, verbose_every=2500):
    set_all_seeds(cfg.seed)
    os.makedirs(cfg.out_dir, exist_ok=True)

    pairs = make_pairs(cfg)
    train_pairs, val_pairs = split_data(pairs, cfg.train_fraction, cfg.seed)
    ordered = apply_curriculum(train_pairs, cfg.curriculum, cfg)

    xtr, ytr = to_tensors(ordered, cfg)
    xva, yva = to_tensors(val_pairs, cfg)
    xtr_eval, ytr_eval = to_tensors(train_pairs, cfg)

    shuffle = (cfg.curriculum == 'random')
    gen = torch.Generator()
    gen.manual_seed(cfg.seed)
    loader = DataLoader(TensorDataset(xtr, ytr), batch_size=cfg.batch_size,
                         shuffle=shuffle, drop_last=True, num_workers=0, generator=gen)

    model = GrokkTransformer(cfg.modulus, cfg.d_model, cfg.n_heads, cfg.n_layers).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr,
                             weight_decay=cfg.weight_decay, betas=(0.9, 0.98))
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / cfg.warmup_steps))

    history, embed_steps, embed_mats = [], [], []

    def loop(dl):
        while True:
            for b in dl:
                yield b

    it = loop(loader)
    t0 = time.time()
    model.train()

    for step in range(cfg.max_steps + 1):
        xb, yb = next(it)
        logits = model(xb.to(device))
        loss = F.cross_entropy(logits, yb.to(device))
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        sched.step()

        if step % cfg.eval_every == 0:
            tr_acc = accuracy(model, xtr_eval, ytr_eval)
            va_acc = accuracy(model, xva, yva)
            history.append({
                'step': step, 'train_loss': float(loss.item()),
                'train_acc': tr_acc, 'val_acc': va_acc,
                'gen_gap': tr_acc - va_acc, 'weight_norm': weight_norm(model),
            })
            if step % verbose_every == 0:
                print('  step %6d | loss %.4f | train %.3f | val %.3f'
                      % (step, loss.item(), tr_acc, va_acc))

        if step % cfg.embed_every == 0:
            embed_steps.append(step)
            embed_mats.append(model.number_embeddings())

    with open(os.path.join(cfg.out_dir, 'history.json'), 'w') as f:
        json.dump({'config': vars(cfg), 'history': history}, f)
    np.savez_compressed(os.path.join(cfg.out_dir, 'embed_log.npz'),
                         steps=np.array(embed_steps),
                         embeds=np.stack(embed_mats).astype(np.float32))

    mins = (time.time() - t0) / 60
    grokk = next((r['step'] for r in history if r['val_acc'] >= 0.95), None)
    print('  done in %.1f min | grokk step: %s' % (mins, grokk))
    return history


if __name__ == '__main__':
    # Example: reproduce one seed of the residue-blocks condition on
    # addition mod 97 (Table 2 / Table 3 in the paper).
    cfg = Config(modulus=97, operation='add', curriculum='residue_blocks',
                 seed=0, out_dir='./runs/add_p97_residue_blocks_s0')
    train(cfg)
